import _ from "lodash";
import "./style.css";
import Vibes from "./vibes";
function component() {
  const element = document.createElement("div");

  element.innerHTML = _.join(["Hello", "Webpack"], " ");
  element.classList.add("hello");

  return element;
}

window.Vibes = Vibes;
// module.exports = Vibes;
