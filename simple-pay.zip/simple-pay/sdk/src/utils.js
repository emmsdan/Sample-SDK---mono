export const verifyKey = (key) => {
  return fetch(
    "https://jsonplaceholder.typicode.com/todos/1"
  ).then((response) => response.json());
};

export const createView = (params, onClose) => {
  const container = document.createElement("div");
  container.style = `
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;  
        `



  const iframe = document.createElement("iframe");
  let searchParams = new URLSearchParams(params.query);

  iframe.id = params.iframeId;
  iframe.src = `${params.url}?${searchParams.toString()}`;
  iframe.title = params.title;
  iframe.width = '300px';
  iframe.height = '300px';
  iframe.scrolling="auto"
  iframe.border = 0
  iframe.style = `
    border: none;
    border-radius: 5px;
    background-color: white;
    overflow: scroll;
    `;

  const button = document.createElement("button");
  button.style = `
  background: red;
  color: white;
  padding: 15px;
        `
  button.textContent = 'Close';
  button.addEventListener('click', ()=>{
    document.body.removeChild(container)
  });
  container.appendChild(button);
  container.appendChild(iframe);
    document.body.appendChild(container);
    return iframe
}

export const iframeWindow = (iframeId) => {
  return document.getElementById(iframeId).contentWindow;
}
