import {createView, iframeWindow, verifyKey} from "./utils";

export default function Vibes(options) {
  try {
    if (!options) {
      throw new Error("Vibes: options are required");
    }
    this.options = options || {};
    const apiKey = this.options.apiKey;
    this.options.iframeId = "vibes-iframe" + Math.floor(Math.random() * 100000);
    verifyKey(apiKey)
      .then((resp) => {
        if (!resp.title) {
          throw new Error("Vibes: apiKey is invalid");
        }
        this.data = resp
      })
      .catch(() => {
        throw new Error("Vibes: apiKey is required");
      });
  } catch (error) {
    this.__failure(error);
  }
}

Vibes.prototype.__failure = function (error) {
  if (this.options.onError) {
    this.options.onError(error);
  }
  if (this.__failedCallback) {
    this.__failedCallback(error);
  }
};

Vibes.prototype.__success = function (data) {
  if (this.options.onSuccess) {
    this.options.onSuccess(data);
  }
  if (this.__successCallback) {
    this.__successCallback(data);
  }
};

Vibes.prototype.start = function () {
  if (this.data && this.options) {
    const iframe = createView({
      ...this.options,
      url: 'http://localhost:3000/',
      title: 'Vibes',
      query: this.data
    })
    // this.listen(iframe)

  }
};

window.addEventListener('message', function (e) {
  console.log('dsfdsfsd', e);
});
Vibes.prototype.listen = function(iframe) {
  iframe.addEventListener("message", (event) => {
    console.log(event.data);
    alert(event.data);
  } );

};
