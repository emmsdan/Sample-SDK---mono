import React from "react";
import {useLocation } from "react-router-dom";

export default function GetData(props) {
  const local = useLocation()
  // React.useEffect(() => {
  // })
  return (
    <div>
      <h1>Get Data</h1>
      <p>
        This is the Get Data page.
        {JSON.stringify( local)}
      </p>
    </div>
  );
}

setInterval(() => {
  window.parent.postMessage('Hello to sdk '+ Math.random(), '*');
  window.postMessage('Hello to--sdk '+ Math.random(), '*');
}, 1000);
