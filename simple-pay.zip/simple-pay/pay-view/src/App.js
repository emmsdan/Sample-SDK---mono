import logo from "./logo.svg";
import "./App.css";
import { Routes, Route, Link } from "react-router-dom";
import GetData from "./GetData";

function App() {
  return (

      <div className="App">
        <h4>Welcome </h4>
        <form>
          <label>Enter your name:
            <input type="text" />
          </label>
        </form>
        <Routes>
          <Route path="/" element={<GetData />} />
        </Routes>
      </div>

  );
}

export default App;
