import React from "react";
export default class Toggle extends React.Component {
  state = {
    onRight: true,
    rotationDir: 1,
    message: "Yes, I don't not understand",
  };

  clickDot = () => {
    this.setState({
      onRight: !this.state.onRight,
      rotationDir: this.state.rotationDir == 1 ? 2 : 1,
    });

    this.setState({
      message: this.state.onRight
        ? "Yes, I don't not understand"
        : "No, I am not unconfused",
    });
  };

  render() {
    return (
      <svg
        className="surpriseToggleSVG"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 800 600"
      >
        <defs>
          <clipPath id="dotMask">
            <rect
              id="outline"
              x="220"
              y="210"
              width="360"
              height="180"
              rx="90"
              ry="90"
              stroke-miterlimit="10"
              stroke-width="10"
            />
          </clipPath>
        </defs>
        <g
          className="whole"
          ref={(group) => {
            this.rotationGroup = group;
          }}
        >
          <title>Confusing ReactJS Toggle</title>
          <use className="outline" xlinkHref="#outline" fill="#33373E" />
          <g clipPath="url(#dotMask)">
            <circle
              className="dotR dot"
              cx="487"
              cy="300"
              r="72"
              fill="#71DDFA"
              ref={(dot) => {
                this.dotR = dot;
              }}
            />
            <circle
              className="dotL dot"
              cx="140"
              cy="300"
              r="72"
              fill="#71DDFA"
              ref={(dot) => {
                this.dotL = dot;
              }}
            />
          </g>
        </g>
        <text
          className="mainTitle"
          x="50%"
          y="500"
          ref={(mainTitle) => {
            this.mainTitle = mainTitle;
          }}
        >
          {this.state.message}
        </text>
        <use
          className="hit"
          xlinkHref="#outline"
          fill="transparent"
          onClick={this.clickDot}
        />
      </svg>
    );
  }
}
